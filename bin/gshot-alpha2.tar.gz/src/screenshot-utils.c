/* screenshot-utils.c - common functions for GNOME Screenshot
 *
 * Copyright (C) 2001-2006  Jonathan Blandford <jrb@alum.mit.edu>
 * Copyright (C) 2008 Cosimo Cecchi <cosimoc@gnome.org>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 */

#include "config.h"

#include "screenshot-utils.h"

#include <gtk/gtk.h>
#include <glib.h>
#include <glib/gi18n.h>

#include "screenshot-backend-shell.h"

#ifdef HAVE_WAYLAND
#include "screenshot-backend-wayland.h"
#include <gdk/wayland/gdkwayland.h>
#endif

#ifdef HAVE_X11
#include "screenshot-backend-x11.h"
#endif

GdkPixbuf *
screenshot_get_pixbuf (GdkRectangle *rectangle)
{
  GdkPixbuf *screenshot = NULL;
  gboolean force_fallback = FALSE;
  g_autoptr (ScreenshotBackend) backend = NULL;
  GdkDisplay *display;

  display = gdk_display_get_default ();

#ifdef HAVE_X11
  force_fallback = g_getenv ("GNOME_SCREENSHOT_FORCE_FALLBACK") != NULL;
#endif

  if (!force_fallback)
    {
      /* Try Wayland first if on Wayland */
#ifdef HAVE_WAYLAND
      if (GDK_IS_WAYLAND_DISPLAY (display))
        {
          backend = screenshot_backend_wayland_new ();
          screenshot = screenshot_backend_get_pixbuf (backend, rectangle);
          if (!screenshot)
            {
              g_message ("Wayland backend failed, attempting fallback methods...");
            }
          else
            {
              return screenshot;
            }
        }
#endif

      /* Fall back to GNOME Shell DBus */
      if (!screenshot)
        {
          g_clear_object (&backend);
          backend = screenshot_backend_shell_new ();
          screenshot = screenshot_backend_get_pixbuf (backend, rectangle);
          if (!screenshot)
            {
              g_message ("GNOME Shell DBus backend failed");
            }
          else
            {
              return screenshot;
            }
        }

      /* Final fallback to X11 - only if not already on Wayland */
#ifdef HAVE_X11
      if (!screenshot && !GDK_IS_WAYLAND_DISPLAY (display))
        {
          g_clear_object (&backend);
          backend = screenshot_backend_x11_new ();
          screenshot = screenshot_backend_get_pixbuf (backend, rectangle);
          if (!screenshot)
            g_message ("All screenshot backends failed");
        }
      else if (!screenshot)
        {
          g_message ("All screenshot backends failed (X11 not available on Wayland)");
        }
#endif
    }
  else
    {
      g_message ("Using fallback methods as requested");

#ifdef HAVE_X11
      if (!screenshot && !GDK_IS_WAYLAND_DISPLAY (display))
        {
          g_clear_object (&backend);
          backend = screenshot_backend_x11_new ();
          screenshot = screenshot_backend_get_pixbuf (backend, rectangle);
        }
      else if (!screenshot)
        {
          g_message ("Cannot use X11 fallback on Wayland");
        }
#endif
    }

  return screenshot;
}

typedef struct
{
  ScreenshotResponseFunc callback;
  gpointer user_data;
} DialogData;

static void
response_cb (GtkDialog  *dialog,
             gint        response_id,
             DialogData *data)
{
  gtk_window_destroy (GTK_WINDOW (dialog));

  if (data->callback)
    data->callback (response_id, data->user_data);

  g_free (data);
}

void
screenshot_show_dialog (GtkWindow              *parent,
                        GtkMessageType          message_type,
                        GtkButtonsType          buttons_type,
                        const gchar            *message,
                        const gchar            *detail,
                        ScreenshotResponseFunc  callback,
                        gpointer                user_data)
{
  DialogData *data;
  GtkWidget *dialog;
  GtkWindowGroup *group;

  g_return_if_fail ((parent == NULL) || (GTK_IS_WINDOW (parent)));
  g_return_if_fail (message != NULL);

  data = g_new0 (DialogData, 1);
  dialog = gtk_message_dialog_new (parent,
                                   GTK_DIALOG_DESTROY_WITH_PARENT,
                                   message_type,
                                   buttons_type,
                                   "%s", message);

  if (detail)
    gtk_message_dialog_format_secondary_text (GTK_MESSAGE_DIALOG (dialog),
                                              "%s", detail);

  if (parent)
    {
      group = gtk_window_get_group (parent);
      if (group != NULL)
        gtk_window_group_add_window (group, GTK_WINDOW (dialog));
    }

  data->callback = callback;
  data->user_data = user_data;

  if (callback)
    g_signal_connect (dialog, "response", G_CALLBACK (response_cb), data);

  gtk_window_present (GTK_WINDOW (dialog));
}

void
screenshot_display_help (GtkWindow *parent)
{
  g_autoptr(GError) error = NULL;

  gtk_show_uri (parent,
                "help:gnome-help/screen-shot-record",
                GDK_CURRENT_TIME);

  if (error)
    screenshot_show_dialog (parent,
                            GTK_MESSAGE_ERROR,
                            GTK_BUTTONS_OK,
                            _("Error loading the help page"),
                            error->message,
                            NULL,
                            NULL);
}
